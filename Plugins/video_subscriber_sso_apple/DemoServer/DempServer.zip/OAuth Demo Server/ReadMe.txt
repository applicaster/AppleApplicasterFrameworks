Host the IdP and SP folders then you will need to add the TV Provider to your test device:

Settings > Developer > TV Providers > Add TV Provider

Identifier: test.mso.oauth
Name: OAuth
Auth URL: http://yourserver/IdP/application.js

Then you need to update the Endpoint Struct in the Xcode project to point to the SP folder you hosted:

Xcode Project > AppleTVE > Shared > Utilities.swift

struct Endpoints {
    static let verificationToken = "https://yourserver/SP/verificationToken?providerID="
    static let authentication = "https://yourserver/SP/authN"
    static let authorization = "https://yourserver/SP/authZ"
}

Last update the Targets' provisioning profiles and bundle identifiers then build and run.