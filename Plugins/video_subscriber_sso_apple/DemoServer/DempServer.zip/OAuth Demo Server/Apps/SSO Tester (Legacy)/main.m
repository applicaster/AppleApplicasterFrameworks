//
//  main.m
//  SSO Tester (Legacy)
//
//  Created by Jared Rogers on 4/5/17.
//  Copyright © 2017 Apple, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TVMLKit/TVMLKit.h>
#import <Foundation/Foundation.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
        [standardUserDefaults setObject:@(YES) forKey:@"JavaScriptCoreOutputConsoleMessagesToSystemConsole"];
        [standardUserDefaults setObject:@(YES) forKey:@"TracingEnabled"];
        [standardUserDefaults setObject:@(YES) forKey:@"LogJSConsole"];
        
        return UIApplicationMain(argc, argv, @"TVLApplication", @"TVLAppDelegate");
    }
}
